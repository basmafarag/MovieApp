package com.example.android.movieapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

//oncreate view
    //connect xml with java
public class main_Fragment extends Fragment {
    GridView gridView;
    Adapter adapter;
    ArrayList<Filter> filters;

    public main_Fragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main_, container, false);
        gridView = (GridView) view.findViewById(R.id.gridView);
        Fetch fetch = new Fetch();
        try {
            Log.i("strt", "Start");
            filters = fetch.execute().get();
            if (filters != null) {
                //  Log.i("count", moviesResult.size()+"");
            } else {
                //  Log.i("count", "null");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        adapter = new Adapter(getContext(), filters);
        gridView.setAdapter(adapter);
        return view;
    }


    public class Fetch extends AsyncTask<String, Void, ArrayList<Filter>> {
        ArrayList<Filter> filters;

        @Override
        protected ArrayList doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;


            try {
                String baseUrl = "http://api.themoviedb.org/3/movie/popular?api_key";
                String apiKey = "0ae7a182ab09b3fd29e71986c7325f92";
                URL url = new URL(baseUrl.concat(apiKey));


                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {

                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                String
                        forecastJsonStr = buffer.toString();

            } catch (IOException e) {

                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {

                    }
                }
            }
            return filters;
        }

        public ArrayList<Filter> moviesObj(String jsonObj) throws JSONException {
            JSONObject jsonObject;
            JSONArray internalArray;
            //the movie
            jsonObject = new JSONObject(jsonObj);
            //all movies
            internalArray = jsonObject.getJSONArray("results");
            Filter movie = null;
            //the result
            ArrayList<Filter> sContent = new ArrayList<>();

            for (int i = 0; i < internalArray.length(); i++) {
                movie.setPosterPath(internalArray.getJSONObject(i).getString("poster_path"));
                movie.setOverview(internalArray.getJSONObject(i).getString("overview"));
                movie.setId(internalArray.getJSONObject(i).getInt("id"));
                movie.setDate(internalArray.getJSONObject(i).getInt("release_date"));
                sContent.add(movie);

                //movie.vote_average=internalArray.getJSONObject(i).getDouble("vote_average");
                //movie.original_title=internalArray.getJSONObject(i).getString("original_title");
                //movie.popularity=internalArray.getJSONObject(i).getInt("popularity");
            }
            return sContent;
        }
        // @Override
        //    protected void onprogressUpdate(Integer...values){
        //      super.onProgressUpdate(values);


        @Override
        protected void onPostExecute(ArrayList<Filter> movies) {
            super.onPostExecute(movies);
            //notify adapter


        }

    }


}