package com.example.android.movieapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by basma_000 on 10/21/2016.
 */
public class Adapter extends BaseAdapter {
    Context mContex;
    List<Filter>gridPost;
    public Adapter(Context mContex,List<Filter> gridPost){
        this.gridPost=new ArrayList<>();
        this.gridPost=gridPost;
        this.mContex=mContex;
    }


    @Override
    public int getCount()
    {
        return  gridPost.size();
    }

    @Override
    public Object getItem(int i)
    {
        return gridPost.get(i);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        View view= convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) mContex.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.grid_movie_item, null);
        }
        String  Base_Url ="http://image.tmdb.org/t/p/w185";
        String Img_url= Base_Url+gridPost.get(i).toString();



        ImageView ivMoviePoster=(ImageView) view.findViewById(R.id.iv_movie_poster);

        Picasso.with(mContex).load(Img_url).into(ivMoviePoster);
        return view;



    }



}
