package com.example.android.movieapp;

public class Filter {
    private String poster_path;
    private String overview;
    private int date;
    private int id;
    private double vote_average;
    private String original_title;
    private int popularity;
    private double vote_popularity;

    public String getPosterPath() {
        return poster_path;
    }

    public void setPosterPath(String poster_Path) {
        this.poster_path = poster_Path;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        overview = overview;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

}
